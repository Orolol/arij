# Pi for Arij

Fork: https://github.com/Orolol/pi, branch `arij`.
Base: Pi v0.85.1, commit `d981de1229ef899957bbe968bc8dcda02a21f477`.

This fork adds `--mcp-config <file>` to the standard interactive, JSON and RPC
CLI. The file is the entire MCP configuration for that process. No global or
project MCP configuration is discovered or modified. An unavailable configured
server fails startup before prompting the model.

```json
{
  "mcpServers": {
    "arij": {
      "command": "node",
      "args": ["/absolute/path/arij-mcp.mjs"],
      "env": { "ARIJ_MCP_TOKEN": "per-session-token" },
      "toolAllowlist": ["get_ticket", "post_comment"]
    },
    "remote": {
      "url": "http://127.0.0.1:8080/mcp",
      "headers": { "Authorization": "Bearer example" },
      "timeoutMs": 30000
    }
  }
}
```

Supported transports: stdio and Streamable HTTP. Tools retain their schemas,
text/image results and error status. Names are `mcp__<server>__<tool>` and must
fit the 64-character model API limit. `toolAllowlist` omitted means all tools;
an empty array means none. Calls support abort signals and bounded timeouts.
MCP resources returned by tools are retained; standalone MCP resource/prompt
browsers, legacy SSE endpoints and HTTP OAuth enrollment are not implemented.

`--tools` keeps its upstream meaning. `--builtin-tools read,grep,find,ls`
enables exactly those built-ins plus configured MCP tools, allowing board
operations in read-only repository sessions. Arij also passes `--no-extensions`.
This is tool restriction, not an OS sandbox against the current user's files.

JSON print mode returns a non-zero exit code on model errors and aborts.
Normal Pi model selection, authentication, sessions, compaction and event
formats are preserved. Arij's distribution uses `~/.arij-pi/agent` for settings,
credentials and sessions, and is packaged as `@arij/pi` with an `arij-pi` binary.
Use `arij pi` to access it from the orchestrator. Credentials still need setup.

## Development and packaging

Node >=22.19 is required. From the source fork:

```sh
npm ci --ignore-scripts
npm run hydrate:model-data
npm run build:offline
npm run check
cd packages/coding-agent
node ../../node_modules/vitest/vitest.mjs run test/arij-mcp.test.ts test/arij-cli.test.ts
cd ../..
node scripts/pack-arij.mjs /path/to/arji/vendor
```

Arij checks the generated tarball into `vendor` and installs it as an exact
local dependency. Installation needs neither a global Pi nor a source build.
The tarball metadata records both upstream and fork revisions; Arij's lockfile
records its integrity and transitive dependencies. Update the source fork,
repeat these checks, then replace the archive and lockfile together.
